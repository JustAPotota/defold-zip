# Native extension template
This template contains the basic setup for creation of a Defold native extension.

You can learn more about native extensions in the [official manual](https://www.defold.com/manuals/extensions/).
